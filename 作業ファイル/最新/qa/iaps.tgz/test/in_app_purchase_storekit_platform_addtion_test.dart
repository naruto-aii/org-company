// Copyright 2013 The Flutter Authors
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

import 'package:flutter_test/flutter_test.dart';
import 'package:in_app_purchase_platform_interface/in_app_purchase_platform_interface.dart';
import 'package:in_app_purchase_storekit/in_app_purchase_storekit.dart';
import 'package:in_app_purchase_storekit/src/in_app_purchase_apis.dart';

import 'fakes/fake_storekit_platform.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  final fakeStoreKitPlatform = FakeStoreKitPlatform();

  setUpAll(() {
    setInAppPurchaseHostApis(api: fakeStoreKitPlatform);
  });

  group('present code redemption sheet', () {
    test('in storekit 1', () async {
      await InAppPurchaseStoreKitPlatform.enableStoreKit1();
      expect(InAppPurchaseStoreKitPlatformAddition().presentCodeRedemptionSheet(), completes);
    });
  });

  group('present code redemption sheet', () {
    test('in storekit 2', () async {
      expect(InAppPurchaseStoreKitPlatformAddition().presentCodeRedemptionSheet(), completes);
    });
  });

  group('refresh receipt data', () {
    test('should refresh receipt data', () async {
      final PurchaseVerificationData? receiptData = await InAppPurchaseStoreKitPlatformAddition()
          .refreshPurchaseVerificationData();
      expect(receiptData, isNotNull);
      expect(receiptData!.source, kIAPSource);
      expect(receiptData.localVerificationData, 'refreshed receipt data');
      expect(receiptData.serverVerificationData, 'refreshed receipt data');
    });
  });
}
